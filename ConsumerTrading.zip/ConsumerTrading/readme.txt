To Process the CSV to XML

1. Selected the required csv file
2. Click upload to upload the file
3. Click Process CSV to XML
4. Select a location to save the XML file
5. A preview of the XML file will be shown on screen and an alert will be shown on screen confirmed the file has been processed
6. If no errors were picked up the generated XML file will be in your chosen save file location
